# Uganda Safari Tours Web Application

## Overview

This is a full-stack web application for a Uganda safari tour company, built with a modern JavaScript/TypeScript stack. The application features a React frontend with a Node.js/Express backend, using PostgreSQL for data persistence and Drizzle ORM for database operations.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight client-side routing)
- **State Management**: TanStack Query (React Query) for server state
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom safari-themed color palette
- **Form Handling**: React Hook Form with Zod validation
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Runtime**: Node.js with TypeScript
- **Framework**: Express.js for REST API
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Validation**: Zod schemas shared between frontend and backend
- **Session Management**: Express sessions with PostgreSQL store

### Data Storage
- **Primary Database**: PostgreSQL (configured for Neon Database)
- **ORM**: Drizzle ORM with type-safe queries
- **Migrations**: Drizzle Kit for database schema management
- **Fallback Storage**: In-memory storage class for development

## Key Components

### Database Schema
The application uses two main tables:
- **users**: Basic user authentication (id, username, password)
- **contact_inquiries**: Tour inquiry submissions with fields for contact info, tour preferences, travel details, and messages

### API Structure
RESTful API endpoints:
- `POST /api/contact` - Submit new tour inquiries
- `GET /api/contact` - Retrieve all inquiries (admin)
- `GET /api/contact/:id` - Retrieve specific inquiry

### Frontend Components
- **Home Page**: Main landing page with tour showcase and contact forms
- **Contact Modal**: Reusable modal for tour inquiries
- **UI Components**: Comprehensive set of shadcn/ui components
- **Form Validation**: Client-side validation with Zod schemas

### Shared Code
- **Schema Definitions**: Drizzle table schemas and Zod validation schemas in `/shared`
- **Type Safety**: TypeScript types generated from database schema
- **Validation**: Shared validation logic between frontend and backend

## Data Flow

1. **User Interaction**: Users browse tours and submit contact inquiries
2. **Form Validation**: Client-side validation using shared Zod schemas
3. **API Communication**: TanStack Query manages API calls with automatic retries
4. **Server Processing**: Express routes validate and process requests
5. **Database Operations**: Drizzle ORM handles type-safe database queries
6. **Response Handling**: Success/error states managed through React Query

## External Dependencies

### Database
- **Neon Database**: Serverless PostgreSQL for production
- **Connection**: Uses DATABASE_URL environment variable
- **Session Store**: PostgreSQL session storage with connect-pg-simple

### UI & Styling
- **Radix UI**: Headless component primitives
- **Tailwind CSS**: Utility-first styling framework
- **Lucide React**: Icon library
- **Embla Carousel**: Carousel component for tour showcases

### Development Tools
- **Vite**: Fast build tool with HMR
- **TypeScript**: Type safety across the stack
- **ESBuild**: Fast JavaScript bundler for production
- **Replit**: Development environment with built-in PostgreSQL

## Deployment Strategy

### Development
- **Environment**: Replit with Node.js 20, PostgreSQL 16
- **Hot Reload**: Vite dev server with Express backend
- **Database**: Local PostgreSQL instance or Neon Database
- **Port**: Application runs on port 5000

### Production
- **Build Process**: Vite builds frontend, ESBuild bundles backend
- **Deployment Target**: Replit Autoscale
- **Static Assets**: Frontend built to `dist/public`
- **Server Bundle**: Backend bundled to `dist/index.js`
- **Environment Variables**: DATABASE_URL required for database connection

### Configuration
- **Database Configuration**: Drizzle config points to shared schema
- **Build Scripts**: Separate build processes for frontend and backend
- **Environment Detection**: Different behavior for development vs production
- **Asset Serving**: Express serves static files in production mode

The application is designed for a tour company showcasing Uganda safari experiences, with a focus on user-friendly tour browsing and inquiry submission. The architecture prioritizes type safety, performance, and maintainability while providing a rich user experience for potential safari customers.