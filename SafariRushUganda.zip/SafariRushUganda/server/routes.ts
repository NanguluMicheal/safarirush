import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactInquirySchema } from "@shared/schema";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // Contact inquiry routes
  app.post("/api/contact", async (req, res) => {
    try {
      const result = insertContactInquirySchema.safeParse(req.body);
      if (!result.success) {
        const errorMessage = fromZodError(result.error);
        return res.status(400).json({ 
          success: false, 
          message: errorMessage.toString()
        });
      }
      
      const createdInquiry = await storage.createContactInquiry(result.data);
      res.json({ 
        success: true, 
        message: "Thank you for your inquiry! We'll get back to you within 24 hours.",
        inquiry: createdInquiry 
      });
    } catch (error: any) {
      res.status(400).json({ 
        success: false, 
        message: error.message || "Failed to submit inquiry" 
      });
    }
  });

  app.get("/api/contact", async (req, res) => {
    try {
      const inquiries = await storage.getContactInquiries();
      res.json(inquiries);
    } catch (error: any) {
      res.status(500).json({ 
        success: false, 
        message: "Failed to fetch inquiries" 
      });
    }
  });

  app.get("/api/contact/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ 
          success: false, 
          message: "Invalid inquiry ID" 
        });
      }

      const inquiry = await storage.getContactInquiry(id);
      if (!inquiry) {
        return res.status(404).json({ 
          success: false, 
          message: "Inquiry not found" 
        });
      }

      res.json(inquiry);
    } catch (error: any) {
      res.status(500).json({ 
        success: false, 
        message: "Failed to fetch inquiry" 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
