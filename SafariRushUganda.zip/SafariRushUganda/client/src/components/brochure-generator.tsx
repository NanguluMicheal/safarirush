import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";

const tours = [
  {
    title: "Gorilla Trekking Experience",
    description: "Get up close with mountain gorillas in Bwindi Impenetrable Forest. An once-in-a-lifetime encounter with our gentle giants.",
    price: 1200,
    duration: "3 Days",
    category: "Premium"
  },
  {
    title: "Queen Elizabeth Safari",
    description: "Explore diverse ecosystems and spot the Big Five in Uganda's most visited national park with boat safaris on Kazinga Channel.",
    price: 950,
    duration: "4 Days",
    category: "Popular"
  },
  {
    title: "Murchison Falls Adventure",
    description: "Witness the mighty Nile squeeze through a 7-meter gap and enjoy game drives in Uganda's largest national park.",
    price: 1050,
    duration: "5 Days",
    category: "Adventure"
  },
  {
    title: "Cultural Heritage Tour",
    description: "Immerse yourself in Ugandan culture, visit traditional villages, and learn about local customs and traditions.",
    price: 650,
    duration: "3 Days",
    category: "Cultural"
  },
  {
    title: "Ultimate Luxury Safari",
    description: "Experience Uganda in ultimate comfort with premium accommodations, private guides, and exclusive wildlife encounters.",
    price: 2800,
    duration: "7 Days",
    category: "Luxury"
  },
  {
    title: "Photography Safari",
    description: "Perfect for photography enthusiasts with expert guides, optimal timing, and exclusive access to the best wildlife spots.",
    price: 1450,
    duration: "6 Days",
    category: "Photo"
  }
];

export function BrochureGenerator() {
  const generatePDF = () => {
    const brochureContent = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Safari Rush Uganda - Tour Brochure</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 20px;
            background: linear-gradient(135deg, #f97316, #059669);
            min-height: 100vh;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        }
        .header {
            background: linear-gradient(135deg, #f97316, #059669);
            color: white;
            padding: 40px;
            text-align: center;
        }
        .header h1 {
            font-size: 3em;
            margin: 0;
            font-weight: bold;
        }
        .header p {
            font-size: 1.2em;
            margin: 10px 0 0 0;
            opacity: 0.9;
        }
        .content {
            padding: 40px;
        }
        .intro {
            text-align: center;
            margin-bottom: 40px;
        }
        .intro h2 {
            color: #f97316;
            font-size: 2em;
            margin-bottom: 15px;
        }
        .intro p {
            font-size: 1.1em;
            color: #666;
            line-height: 1.6;
        }
        .tours-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }
        .tour-card {
            border: 2px solid #f97316;
            border-radius: 10px;
            padding: 20px;
            background: #fef7ff;
        }
        .tour-card h3 {
            color: #f97316;
            font-size: 1.4em;
            margin: 0 0 10px 0;
        }
        .tour-details {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 10px 0;
        }
        .price {
            font-size: 1.8em;
            font-weight: bold;
            color: #059669;
        }
        .duration {
            background: #f97316;
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.9em;
        }
        .category {
            background: #059669;
            color: white;
            padding: 3px 10px;
            border-radius: 15px;
            font-size: 0.8em;
            margin-bottom: 10px;
            display: inline-block;
        }
        .description {
            color: #666;
            line-height: 1.5;
            margin: 10px 0;
        }
        .contact {
            background: linear-gradient(135deg, #f97316, #059669);
            color: white;
            padding: 30px;
            border-radius: 10px;
            text-align: center;
        }
        .contact h2 {
            margin: 0 0 20px 0;
            font-size: 2em;
        }
        .contact-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .contact-item {
            background: rgba(255,255,255,0.1);
            padding: 15px;
            border-radius: 8px;
        }
        .contact-item h4 {
            margin: 0 0 10px 0;
            font-size: 1.1em;
        }
        .footer {
            text-align: center;
            padding: 20px;
            background: #f8f9fa;
            color: #666;
            font-size: 0.9em;
        }
        @media print {
            body { background: white; }
            .container { box-shadow: none; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔭 Safari Rush Uganda</h1>
            <p>Discover the Wild Beauty of Uganda</p>
        </div>
        
        <div class="content">
            <div class="intro">
                <h2>Unforgettable Safari Adventures Await</h2>
                <p>Experience breathtaking safaris, encounter magnificent wildlife, and create memories that last a lifetime with Uganda's premier adventure company. From thrilling gorilla trekking to luxury safaris, we offer carefully crafted tours that showcase the best of Uganda's natural wonders.</p>
            </div>
            
            <div class="tours-grid">
                ${tours.map(tour => `
                    <div class="tour-card">
                        <span class="category">${tour.category}</span>
                        <h3>${tour.title}</h3>
                        <p class="description">${tour.description}</p>
                        <div class="tour-details">
                            <span class="price">$${tour.price}</span>
                            <span class="duration">${tour.duration}</span>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
        
        <div class="contact">
            <h2>📞 Contact Us Today</h2>
            <p>Ready to embark on your Uganda safari adventure? Get in touch with our expert team!</p>
            
            <div class="contact-info">
                <div class="contact-item">
                    <h4>📧 Email</h4>
                    <p>info@safarirusuganda.com<br>bookings@safarirusuganda.com</p>
                </div>
                <div class="contact-item">
                    <h4>📱 Phone</h4>
                    <p>+256 700 123 456<br>+256 775 987 654</p>
                </div>
                <div class="contact-item">
                    <h4>📍 Location</h4>
                    <p>Kampala, Uganda<br>Plot 123, Safari Street</p>
                </div>
                <div class="contact-item">
                    <h4>🌐 Website</h4>
                    <p>www.safarirusuganda.com</p>
                </div>
            </div>
        </div>
        
        <div class="footer">
            <p>© 2024 Safari Rush Uganda. All rights reserved. | Licensed Tour Operator | Eco-Friendly Tourism</p>
        </div>
    </div>
</body>
</html>
    `;

    // Create and download the brochure
    const blob = new Blob([brochureContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'Safari-Rush-Uganda-Brochure.html';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <Button
      onClick={generatePDF}
      className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors duration-200 shadow-lg"
    >
      <Download className="mr-2 w-4 h-4" />
      Download Brochure
    </Button>
  );
}