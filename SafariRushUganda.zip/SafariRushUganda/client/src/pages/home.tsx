import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  insertContactInquirySchema,
  type InsertContactInquiry,
} from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { ContactModal } from "@/components/contact-modal";
import { BrochureGenerator } from "@/components/brochure-generator";
import logoPath from "@assets/IMG_3027.jpeg";
import {
  Binoculars,
  Phone,
  Mail,
  MapPin,
  Clock,
  Facebook,
  Instagram,
  Twitter,
  Youtube,
  Star,
  Award,
  Leaf,
  Shield,
  Heart,
  Menu,
  X,
  ChevronDown,
  Compass,
  Calendar,
  PlaneTakeoff,
  Camera,
} from "lucide-react";

const tours = [
  {
    id: "gorilla-trekking",
    title: "Gorilla Trekking Experience",
    description:
      "Get up close with mountain gorillas in Bwindi Impenetrable Forest. An once-in-a-lifetime encounter with our gentle giants.",
    price: 1200,
    duration: "3 Days",
    rating: 5,
    reviews: 47,
    category: "Premium",
    categoryColor: "bg-red-600",
    image:
      "https://images.unsplash.com/photo-1544735716-392fe2489ffa?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
  },
  {
    id: "queen-elizabeth",
    title: "Queen Elizabeth Safari",
    description:
      "Explore diverse ecosystems and spot the Big Five in Uganda's most visited national park with boat safaris on Kazinga Channel.",
    price: 950,
    duration: "4 Days",
    rating: 5,
    reviews: 63,
    category: "Popular",
    categoryColor: "bg-green-600",
    image:
      "https://images.unsplash.com/photo-1551969014-7d2c4cddf0b6?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
  },
  {
    id: "murchison-falls",
    title: "Murchison Falls Adventure",
    description:
      "Witness the mighty Nile squeeze through a 7-meter gap and enjoy game drives in Uganda's largest national park.",
    price: 1050,
    duration: "5 Days",
    rating: 4.5,
    reviews: 34,
    category: "Adventure",
    categoryColor: "bg-blue-600",
    image:
      "https://pixabay.com/get/gc5c83fd0daf520eddd2025b48a23feffdb38a45bb665d03e91546d19a22e13cccf6e71fda34b05008d6f24653251689df1fc96bc4d7687264e9204ef7cf9e6f5_1280.jpg",
  },
  {
    id: "cultural-heritage",
    title: "Cultural Heritage Tour",
    description:
      "Immerse yourself in Ugandan culture, visit traditional villages, and learn about local customs and traditions.",
    price: 650,
    duration: "3 Days",
    rating: 4,
    reviews: 28,
    category: "Cultural",
    categoryColor: "bg-purple-600",
    image:
      "https://images.unsplash.com/photo-1559827260-dc66d52bef19?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
  },
  {
    id: "luxury-safari",
    title: "Ultimate Luxury Safari",
    description:
      "Experience Uganda in ultimate comfort with premium accommodations, private guides, and exclusive wildlife encounters.",
    price: 2800,
    duration: "7 Days",
    rating: 5,
    reviews: 19,
    category: "Luxury",
    categoryColor: "bg-yellow-600",
    image:
      "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
  },
  {
    id: "photography-safari",
    title: "Photography Safari",
    description:
      "Perfect for photography enthusiasts with expert guides, optimal timing, and exclusive access to the best wildlife spots.",
    price: 1450,
    duration: "6 Days",
    rating: 5,
    reviews: 25,
    category: "Photo",
    categoryColor: "bg-indigo-600",
    image:
      "https://pixabay.com/get/g812cd1875983701f7c2730accc6fd48f26ed47215453755f14d613ecf9c0fbe4bbfb13a670ade83f25560c4fc7f1b33a7bd734142585da671525e6b2f63b494c_1280.jpg",
  },
];

const testimonials = [
  {
    name: "Sarah Johnson",
    location: "New York, USA",
    initials: "SJ",
    rating: 5,
    review:
      "The gorilla trekking experience was absolutely life-changing. Our guide was incredibly knowledgeable and the whole team made us feel safe and comfortable throughout the journey.",
    bgColor: "bg-orange-600",
  },
  {
    name: "Michael Peters",
    location: "London, UK",
    initials: "MP",
    rating: 5,
    review:
      "Outstanding service from start to finish. The Queen Elizabeth safari exceeded all our expectations. Professional, friendly, and truly passionate about wildlife conservation.",
    bgColor: "bg-green-600",
  },
  {
    name: "Anna Rodriguez",
    location: "Madrid, Spain",
    initials: "AR",
    rating: 5,
    review:
      "The cultural tour was incredibly enriching. We learned so much about Ugandan traditions and the hospitality was exceptional. Highly recommend Safari Rush!",
    bgColor: "bg-red-600",
  },
];

export default function Home() {
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  const [selectedTour, setSelectedTour] = useState<string>("");
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { toast } = useToast();

  const form = useForm<InsertContactInquiry>({
    resolver: zodResolver(insertContactInquirySchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      tour: "",
      travelDate: "",
      travelers: "",
      message: "",
    },
  });

  const contactMutation = useMutation({
    mutationFn: async (data: InsertContactInquiry) => {
      const response = await apiRequest("POST", "/api/contact", data);
      return response.json();
    },
    onSuccess: (data) => {
      form.reset();
      toast({
        title: "Inquiry Sent Successfully!",
        description: data.message,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description:
          error.message || "Failed to send inquiry. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertContactInquiry) => {
    contactMutation.mutate(data);
  };

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const navHeight = 80;
      const targetPosition = element.offsetTop - navHeight;
      window.scrollTo({
        top: targetPosition,
        behavior: "smooth",
      });
    }
    setIsMobileMenuOpen(false);
  };

  const openContactModal = (tourId?: string) => {
    if (tourId) {
      setSelectedTour(tourId);
    }
    setIsContactModalOpen(true);
  };

  const generateDynamicBrochure = () => {
    const currentDate = new Date().getFullYear();
    const brochureContent = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Safari Rush Uganda - Tour Brochure</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 20px;
            background: linear-gradient(135deg, #f97316, #059669);
            min-height: 100vh;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        }
        .header {
            background: linear-gradient(135deg, #f97316, #059669);
            color: white;
            padding: 40px;
            text-align: center;
        }
        .header h1 {
            font-size: 3em;
            margin: 0;
            font-weight: bold;
        }
        .header p {
            font-size: 1.2em;
            margin: 10px 0 0 0;
            opacity: 0.9;
        }
        .content {
            padding: 40px;
        }
        .intro {
            text-align: center;
            margin-bottom: 40px;
        }
        .intro h2 {
            color: #f97316;
            font-size: 2em;
            margin-bottom: 15px;
        }
        .intro p {
            font-size: 1.1em;
            color: #666;
            line-height: 1.6;
        }
        .tours-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }
        .tour-card {
            border: 2px solid #f97316;
            border-radius: 10px;
            padding: 20px;
            background: #fef7ff;
        }
        .tour-card h3 {
            color: #f97316;
            font-size: 1.4em;
            margin: 0 0 10px 0;
        }
        .tour-details {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 10px 0;
        }
        .price {
            font-size: 1.8em;
            font-weight: bold;
            color: #059669;
        }
        .duration {
            background: #f97316;
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.9em;
        }
        .category {
            background: #059669;
            color: white;
            padding: 3px 10px;
            border-radius: 15px;
            font-size: 0.8em;
            margin-bottom: 10px;
            display: inline-block;
        }
        .description {
            color: #666;
            line-height: 1.5;
            margin: 10px 0;
        }
        .contact {
            background: linear-gradient(135deg, #f97316, #059669);
            color: white;
            padding: 30px;
            border-radius: 10px;
            text-align: center;
        }
        .contact h2 {
            margin: 0 0 20px 0;
            font-size: 2em;
        }
        .contact-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .contact-item {
            background: rgba(255,255,255,0.1);
            padding: 15px;
            border-radius: 8px;
        }
        .contact-item h4 {
            margin: 0 0 10px 0;
            font-size: 1.1em;
        }
        .footer {
            text-align: center;
            padding: 20px;
            background: #f8f9fa;
            color: #666;
            font-size: 0.9em;
        }
        @media print {
            body { background: white; }
            .container { box-shadow: none; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔭 Safari Rush Uganda</h1>
            <p>Discover the Wild Beauty of Uganda</p>
        </div>
        
        <div class="content">
            <div class="intro">
                <h2>Unforgettable Safari Adventures Await</h2>
                <p>Experience breathtaking safaris, encounter magnificent wildlife, and create memories that last a lifetime with Uganda's premier adventure company. From thrilling gorilla trekking to luxury safaris, we offer carefully crafted tours that showcase the best of Uganda's natural wonders.</p>
            </div>
            
            <div class="tours-grid">
                ${tours
                  .map(
                    (tour) => `
                    <div class="tour-card">
                        <span class="category">${tour.category}</span>
                        <h3>${tour.title}</h3>
                        <p class="description">${tour.description}</p>
                        <div class="tour-details">
                            <span class="price">$${tour.price}</span>
                            <span class="duration">${tour.duration}</span>
                        </div>
                    </div>
                `,
                  )
                  .join("")}
            </div>
        </div>
        
        <div class="contact">
            <h2>📞 Contact Us Today</h2>
            <p>Ready to embark on your Uganda safari adventure? Get in touch with our expert team!</p>
            
            <div class="contact-info">
                <div class="contact-item">
                    <h4>📧 Email</h4>
                    <p>info@safarirushuganda.com</p>
                </div>
                <div class="contact-item">
                    <h4>📱 Phone</h4>
                    <p>+256 779 122 114</p>
                </div>
                <div class="contact-item">
                    <h4>📍 Location</h4>
                    <p>Plot 4D Airport Road<br>Entebbe, Uganda</p>
                </div>
                <div class="contact-item">
                    <h4>🌐 Website</h4>
                    <p>www.safarirushuganda.com</p>
                </div>
            </div>
        </div>
        
        <div class="footer">
            <p>© ${currentDate} Safari Rush Uganda. All rights reserved. | Licensed Tour Operator | Eco-Friendly Tourism</p>
        </div>
    </div>
</body>
</html>
    `;

    const blob = new Blob([brochureContent], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "Safari-Rush-Uganda-Brochure.html";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-stone-50">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-white/95 backdrop-blur-md shadow-lg z-50">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <img 
                src={logoPath} 
                alt="Safari Rush Uganda Logo" 
                className="h-10 w-10 object-contain rounded"
              />
              <span className="font-bold text-xl text-gray-800">
                Safari Rush Uganda
              </span>
            </div>

            {/* Desktop Menu */}
            <div className="hidden md:flex items-center space-x-8">
              <button
                onClick={() => scrollToSection("home")}
                className="text-gray-700 hover:text-orange-600 transition-colors duration-200 font-medium"
              >
                Home
              </button>
              <button
                onClick={() => scrollToSection("tours")}
                className="text-gray-700 hover:text-orange-600 transition-colors duration-200 font-medium"
              >
                Tours
              </button>
              <button
                onClick={() => scrollToSection("about")}
                className="text-gray-700 hover:text-orange-600 transition-colors duration-200 font-medium"
              >
                About
              </button>
              <button
                onClick={() => scrollToSection("contact")}
                className="text-gray-700 hover:text-orange-600 transition-colors duration-200 font-medium"
              >
                Contact
              </button>
              <Button
                onClick={() => openContactModal()}
                className="bg-orange-600 text-white px-6 py-2 rounded-full hover:bg-orange-700 transition-colors duration-200 font-medium"
              >
                Book Now
              </Button>
            </div>

            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X /> : <Menu />}
            </Button>
          </div>

          {/* Mobile Menu */}
          {isMobileMenuOpen && (
            <div className="md:hidden bg-white border-t py-4 space-y-4">
              <button
                onClick={() => scrollToSection("home")}
                className="block w-full text-left text-gray-700 hover:text-orange-600 transition-colors duration-200"
              >
                Home
              </button>
              <button
                onClick={() => scrollToSection("tours")}
                className="block w-full text-left text-gray-700 hover:text-orange-600 transition-colors duration-200"
              >
                Tours
              </button>
              <button
                onClick={() => scrollToSection("about")}
                className="block w-full text-left text-gray-700 hover:text-orange-600 transition-colors duration-200"
              >
                About
              </button>
              <button
                onClick={() => scrollToSection("contact")}
                className="block w-full text-left text-gray-700 hover:text-orange-600 transition-colors duration-200"
              >
                Contact
              </button>
              <Button
                onClick={() => openContactModal()}
                className="w-full bg-orange-600 text-white py-2 rounded-full hover:bg-orange-700 transition-colors duration-200"
              >
                Book Now
              </Button>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section
        id="home"
        className="relative min-h-screen flex items-center justify-center overflow-hidden"
      >
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage:
              "url('https://images.unsplash.com/photo-1516026672322-bc52d61a55d5?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2048&h=1365')",
          }}
        />
        <div className="absolute inset-0 bg-black/40" />

        <div className="relative z-10 text-center text-white px-4 max-w-4xl mx-auto">
          <h1 className="font-bold text-5xl md:text-7xl mb-6 leading-tight">
            Discover the
            <span className="text-orange-600"> Wild Beauty</span>
            of Uganda
          </h1>
          <p className="text-xl md:text-2xl mb-8 font-light leading-relaxed">
            Experience breathtaking safaris, encounter magnificent wildlife, and
            create memories that last a lifetime with Uganda's premier adventure
            company.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button
              onClick={() => scrollToSection("tours")}
              className="bg-orange-600 hover:bg-orange-700 text-white px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 transform hover:scale-105 shadow-xl"
            >
              <Compass className="mr-2" />
              Explore Tours
            </Button>
            <Button
              onClick={() => openContactModal()}
              variant="outline"
              className="border-2 border-white text-white bg-white/10 backdrop-blur-sm hover:bg-white hover:text-gray-800 px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 transform hover:scale-105"
            >
              <Mail className="mr-2" />
              Get Quote
            </Button>
          </div>
        </div>

        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white animate-bounce">
          <ChevronDown className="text-2xl" />
        </div>
      </section>

      {/* Featured Tours Section */}
      <section id="tours" className="py-20 bg-white">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-bold text-4xl md:text-5xl text-gray-800 mb-4">
              Unforgettable Safari Adventures
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From thrilling wildlife encounters to cultural immersions,
              discover our carefully crafted tours that showcase the best of
              Uganda's natural wonders.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {tours.map((tour) => (
              <Card
                key={tour.id}
                className="overflow-hidden hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2"
              >
                <div className="relative h-64">
                  <img
                    src={tour.image}
                    alt={tour.title}
                    className="w-full h-full object-cover"
                  />
                  <div
                    className={`absolute top-4 left-4 ${tour.categoryColor} text-white px-3 py-1 rounded-full text-sm font-semibold`}
                  >
                    {tour.category}
                  </div>
                  <div className="absolute bottom-4 right-4 bg-black/70 text-white px-3 py-1 rounded-full text-sm">
                    {tour.duration}
                  </div>
                </div>
                <CardContent className="p-6">
                  <CardTitle className="text-xl mb-3">{tour.title}</CardTitle>
                  <p className="text-gray-600 mb-4">{tour.description}</p>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-2xl font-bold text-orange-600">
                      ${tour.price}
                    </span>
                    <div className="flex items-center text-yellow-500">
                      {Array.from({ length: Math.floor(tour.rating) }).map(
                        (_, i) => (
                          <Star key={i} className="w-4 h-4 fill-current" />
                        ),
                      )}
                      {tour.rating % 1 !== 0 && (
                        <Star className="w-4 h-4 fill-current opacity-50" />
                      )}
                      <span className="ml-2 text-gray-600">
                        ({tour.reviews})
                      </span>
                    </div>
                  </div>
                  <Button
                    onClick={() => openContactModal(tour.id)}
                    className="w-full bg-orange-600 hover:bg-orange-700 text-white py-3 rounded-lg font-semibold transition-colors duration-200"
                  >
                    Book This Tour
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center">
            <Button
              onClick={() => openContactModal()}
              className="bg-green-600 hover:bg-green-700 text-white px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg"
            >
              <Calendar className="mr-2" />
              Plan Custom Tour
            </Button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section
        id="about"
        className="py-20 bg-gradient-to-br from-orange-50 to-green-50"
      >
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="font-bold text-4xl md:text-5xl text-gray-800 mb-6">
                Why Choose Safari Rush Uganda?
              </h2>
              <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                Safari Rush Uganda is your gateway to the Pearl of Africa. We're
                a local team passionate about sharing Uganda's wildlife, landscapes
                and cultures through thrilling safaris and gorilla treks.
              </p>

              <div className="grid md:grid-cols-2 gap-6 mb-8">
                <div className="flex items-start space-x-3">
                  <div className="bg-orange-600 text-white p-2 rounded-lg">
                    <Award className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-1">
                      Expert Guides
                    </h4>
                    <p className="text-sm text-gray-600">
                      Certified local guides with deep knowledge of Uganda's
                      wildlife and culture
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <div className="bg-green-600 text-white p-2 rounded-lg">
                    <Leaf className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-1">
                      Sustainable Tourism
                    </h4>
                    <p className="text-sm text-gray-600">
                      Committed to conservation and supporting local communities
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <div className="bg-red-600 text-white p-2 rounded-lg">
                    <Shield className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-1">
                      Safety First
                    </h4>
                    <p className="text-sm text-gray-600">
                      Comprehensive safety protocols and emergency support
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <div className="bg-blue-600 text-white p-2 rounded-lg">
                    <Heart className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-1">
                      Personalized Service
                    </h4>
                    <p className="text-sm text-gray-600">
                      Tailored experiences to match your interests and
                      preferences
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  onClick={() => openContactModal()}
                  className="bg-orange-600 hover:bg-orange-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors duration-200"
                >
                  Learn More About Us
                </Button>
                <Button
                  variant="outline"
                  onClick={generateDynamicBrochure}
                  className="border border-gray-400 text-gray-700 hover:bg-gray-100 px-6 py-3 rounded-lg font-semibold transition-colors duration-200"
                >
                  <PlaneTakeoff className="mr-2 w-4 h-4" />
                  Download Brochure
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <img
                  src="https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300"
                  alt="Professional safari guide"
                  className="rounded-xl shadow-lg w-full h-auto"
                />
                <img
                  src="https://images.unsplash.com/photo-1571896349842-33c89424de2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=250"
                  alt="Luxury safari lodge"
                  className="rounded-xl shadow-lg w-full h-auto"
                />
              </div>

              <div className="space-y-4 mt-8">
                <img
                  src="https://images.unsplash.com/photo-1547036967-23d11aacaee0?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=250"
                  alt="Lions in the wild"
                  className="rounded-xl shadow-lg w-full h-auto"
                />
                <img
                  src="https://images.unsplash.com/photo-1516026672322-bc52d61a55d5?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300"
                  alt="Safari vehicle adventure"
                  className="rounded-xl shadow-lg w-full h-auto"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-bold text-4xl md:text-5xl text-gray-800 mb-4">
              What Our Adventurers Say
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Don't just take our word for it - hear from fellow travelers who
              have experienced the magic of Uganda with Safari Rush.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="bg-stone-50 shadow-lg">
                <CardContent className="p-8">
                  <div className="flex items-center mb-4">
                    <div className="flex text-yellow-500 mr-2">
                      {Array.from({ length: testimonial.rating }).map(
                        (_, i) => (
                          <Star key={i} className="w-4 h-4 fill-current" />
                        ),
                      )}
                    </div>
                  </div>
                  <p className="text-gray-700 mb-6 italic">
                    "{testimonial.review}"
                  </p>
                  <div className="flex items-center">
                    <div
                      className={`w-12 h-12 ${testimonial.bgColor} rounded-full flex items-center justify-center text-white font-bold mr-3`}
                    >
                      {testimonial.initials}
                    </div>
                    <div>
                      <p className="font-semibold text-gray-800">
                        {testimonial.name}
                      </p>
                      <p className="text-sm text-gray-600">
                        {testimonial.location}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section
        id="contact"
        className="py-20 bg-gradient-to-r from-orange-600 to-green-600 text-white"
      >
        <div className="container mx-auto px-4 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-bold text-4xl md:text-5xl mb-4">
              Ready for Your Adventure?
            </h2>
            <p className="text-xl max-w-3xl mx-auto opacity-90">
              Contact us today to start planning your unforgettable Ugandan
              safari experience. Our team of experts is ready to help you create
              memories that will last a lifetime.
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-start">
            <div>
              <div className="space-y-6">
                <div className="flex items-center space-x-4">
                  <div className="bg-white/20 p-3 rounded-lg">
                    <MapPin className="text-xl" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg">Visit Our Office</h4>
                    <p className="opacity-90">
                      Plot 4D Airport Road
                      <br />
                      Entebbe, Uganda
                    </p>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="bg-white/20 p-3 rounded-lg">
                    <Phone className="text-xl" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg">Call Us</h4>
                    <p className="opacity-90">+256 779 122 114</p>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="bg-white/20 p-3 rounded-lg">
                    <Mail className="text-xl" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg">Email Us</h4>
                    <p className="opacity-90">
                      info@safarirushuganda.com
                      <br />
                      bookings@safarirushuganda.com
                    </p>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="bg-white/20 p-3 rounded-lg">
                    <Clock className="text-xl" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg">Office Hours</h4>
                    <p className="opacity-90">
                      Monday - Friday: 8:00 AM - 6:00 PM
                      <br />
                      Saturday: 9:00 AM - 4:00 PM
                    </p>
                  </div>
                </div>
              </div>

              <div className="mt-8 pt-8 border-t border-white/20">
                <h4 className="font-semibold text-lg mb-4">
                  Follow Our Adventures
                </h4>
                <div className="flex space-x-4">
                  <Button
                    size="icon"
                    variant="ghost"
                    className="bg-white/20 hover:bg-white/30 text-white"
                  >
                    <Facebook />
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    className="bg-white/20 hover:bg-white/30 text-white"
                  >
                    <Instagram />
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    className="bg-white/20 hover:bg-white/30 text-white"
                  >
                    <Twitter />
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    className="bg-white/20 hover:bg-white/30 text-white"
                  >
                    <Youtube />
                  </Button>
                </div>
              </div>
            </div>

            <Card className="bg-white text-gray-800 shadow-2xl">
              <CardHeader>
                <CardTitle className="text-2xl text-center">
                  Get Your Free Quote
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form
                    onSubmit={form.handleSubmit(onSubmit)}
                    className="space-y-4"
                  >
                    <div className="grid md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="firstName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>First Name *</FormLabel>
                            <FormControl>
                              <Input placeholder="John" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="lastName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Last Name *</FormLabel>
                            <FormControl>
                              <Input placeholder="Doe" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email Address *</FormLabel>
                          <FormControl>
                            <Input
                              type="email"
                              placeholder="john@example.com"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone Number</FormLabel>
                          <FormControl>
                            <Input
                              type="tel"
                              placeholder="+1 (555) 123-4567"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="tour"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Preferred Tour</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select a tour..." />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {tours.map((tour) => (
                                <SelectItem key={tour.id} value={tour.id}>
                                  {tour.title}
                                </SelectItem>
                              ))}
                              <SelectItem value="custom">
                                Custom Tour
                              </SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="travelDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Travel Dates</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="travelers"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Number of Travelers</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select number..." />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="1">1 Person</SelectItem>
                              <SelectItem value="2">2 People</SelectItem>
                              <SelectItem value="3-4">3-4 People</SelectItem>
                              <SelectItem value="5-8">5-8 People</SelectItem>
                              <SelectItem value="8+">8+ People</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="message"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>
                            Special Requirements or Questions
                          </FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Tell us about any special requirements, dietary restrictions, or questions you have..."
                              className="resize-none"
                              rows={4}
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button
                      type="submit"
                      disabled={contactMutation.isPending}
                      className="w-full bg-orange-600 hover:bg-orange-700 text-white py-4 rounded-lg font-semibold text-lg transition-colors duration-200"
                    >
                      {contactMutation.isPending ? (
                        "Sending..."
                      ) : (
                        <>
                          <Mail className="mr-2" />
                          Send My Quote Request
                        </>
                      )}
                    </Button>

                    <p className="text-sm text-gray-600 text-center">
                      We'll respond within 24 hours with a personalized quote
                      and itinerary.
                    </p>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <img 
                  src={logoPath} 
                  alt="Safari Rush Uganda Logo" 
                  className="h-8 w-8 object-contain rounded"
                />
                <span className="font-bold text-xl">Safari Rush Uganda</span>
              </div>
              <p className="text-gray-400 mb-4">
                Creating unforgettable safari experiences in the Pearl of
                Africa.
              </p>
              <div className="flex space-x-3">
                <Button
                  size="icon"
                  variant="ghost"
                  className="text-gray-400 hover:text-orange-600"
                >
                  <Facebook />
                </Button>
                <Button
                  size="icon"
                  variant="ghost"
                  className="text-gray-400 hover:text-orange-600"
                >
                  <Instagram />
                </Button>
                <Button
                  size="icon"
                  variant="ghost"
                  className="text-gray-400 hover:text-orange-600"
                >
                  <Twitter />
                </Button>
                <Button
                  size="icon"
                  variant="ghost"
                  className="text-gray-400 hover:text-orange-600"
                >
                  <Youtube />
                </Button>
              </div>
            </div>

            <div>
              <h4 className="font-semibold text-lg mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li>
                  <button
                    onClick={() => scrollToSection("home")}
                    className="text-gray-400 hover:text-white transition-colors duration-200"
                  >
                    Home
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => scrollToSection("tours")}
                    className="text-gray-400 hover:text-white transition-colors duration-200"
                  >
                    Tours
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => scrollToSection("about")}
                    className="text-gray-400 hover:text-white transition-colors duration-200"
                  >
                    About Us
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => scrollToSection("contact")}
                    className="text-gray-400 hover:text-white transition-colors duration-200"
                  >
                    Contact
                  </button>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-gray-400 hover:text-white transition-colors duration-200"
                  >
                    Blog
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold text-lg mb-4">Popular Tours</h4>
              <ul className="space-y-2">
                <li>
                  <a
                    href="#"
                    className="text-gray-400 hover:text-white transition-colors duration-200"
                  >
                    Gorilla Trekking
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-gray-400 hover:text-white transition-colors duration-200"
                  >
                    Queen Elizabeth Safari
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-gray-400 hover:text-white transition-colors duration-200"
                  >
                    Murchison Falls
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-gray-400 hover:text-white transition-colors duration-200"
                  >
                    Cultural Tours
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-gray-400 hover:text-white transition-colors duration-200"
                  >
                    Luxury Safaris
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold text-lg mb-4">Contact Info</h4>
              <div className="space-y-3 text-gray-400">
                <p>
                  <MapPin className="inline mr-2 text-orange-600" size={16} />{" "}
                  Plot 4D Airport Road, Entebbe, Uganda
                </p>
                <p>
                  <Phone className="inline mr-2 text-orange-600" size={16} />{" "}
                  +256 779 122 114
                </p>
                <p>
                  <Mail className="inline mr-2 text-orange-600" size={16} />{" "}
                  info@safarirushuganda.com
                </p>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>
              &copy; 2024 Safari Rush Uganda. All rights reserved. |
              <a
                href="#"
                className="hover:text-white transition-colors duration-200 ml-1"
              >
                Privacy Policy
              </a>{" "}
              |
              <a
                href="#"
                className="hover:text-white transition-colors duration-200 ml-1"
              >
                Terms of Service
              </a>
            </p>
          </div>
        </div>
      </footer>

      {/* Contact Modal */}
      <ContactModal
        isOpen={isContactModalOpen}
        onClose={() => setIsContactModalOpen(false)}
        selectedTour={selectedTour}
      />
    </div>
  );
}
